window._CCSettings = {
    platform: "fb-instant-games",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    rawAssets: {
        assets: {
            "ccEsQ/A8JGR7bRnbxyZKcH": [
                "Texture/Loading/frame-0",
                "cc.SpriteFrame",
                1
            ],
            "65oLWRJP1LppfrquGq0zJI": [
                "Texture/Loading/frame-0.png",
                "cc.Texture2D"
            ],
            b5KwyrhupJsKFmjZbVPzjU: [
                "Texture/Loading/frame-1",
                "cc.SpriteFrame",
                1
            ],
            "10tmRch2lO7Jpv40kgi5mX": [
                "Texture/Loading/frame-1.png",
                "cc.Texture2D"
            ],
            "b8+11Hz99HKJK6gB0B/EHN": [
                "Texture/Loading/frame-10",
                "cc.SpriteFrame",
                1
            ],
            "3b4u53J3lC95Jj8VI0hLBb": [
                "Texture/Loading/frame-10.png",
                "cc.Texture2D"
            ],
            "10NqWh1ZVNNb1kEAe6VyRk": [
                "Texture/Loading/frame-11",
                "cc.SpriteFrame",
                1
            ],
            fcB7VZ86pG8YWamkUFmRaR: [
                "Texture/Loading/frame-11.png",
                "cc.Texture2D"
            ],
            "44dmFC6MZOeZQTnbVfGBsk": [
                "Texture/Loading/frame-12",
                "cc.SpriteFrame",
                1
            ],
            "14vb/Yh5RI0Y+G/hZ6t/M7": [
                "Texture/Loading/frame-12.png",
                "cc.Texture2D"
            ],
            e8T6Y0sUNIG7LXnzqyNkl7: [
                "Texture/Loading/frame-13",
                "cc.SpriteFrame",
                1
            ],
            "03w5fB6Y1J3Zsm1hLLvjHx": [
                "Texture/Loading/frame-13.png",
                "cc.Texture2D"
            ],
            "b5Xf8bsV5M7ITS/1xUK7SQ": [
                "Texture/Loading/frame-14",
                "cc.SpriteFrame",
                1
            ],
            e92OZtgL1IqoKZbJwcyJtJ: [
                "Texture/Loading/frame-14.png",
                "cc.Texture2D"
            ],
            "abEu7yE+xFJYkvW/gdDVKa": [
                "Texture/Loading/frame-15",
                "cc.SpriteFrame",
                1
            ],
            c8yvF1B1FKM7bZbhIpWkGo: [
                "Texture/Loading/frame-15.png",
                "cc.Texture2D"
            ],
            "73Whe0ryFBKrsyv0LKUx8f": [
                "Texture/Loading/frame-16",
                "cc.SpriteFrame",
                1
            ],
            "99tm7mqFxASo1a7ZOnLqQZ": [
                "Texture/Loading/frame-16.png",
                "cc.Texture2D"
            ],
            adg0WekRFO1ofUR5zFx0E6: [
                "Texture/Loading/frame-17",
                "cc.SpriteFrame",
                1
            ],
            "16FGsWsIZJWIUmufHNRQSD": [
                "Texture/Loading/frame-17.png",
                "cc.Texture2D"
            ],
            "eaMw1eYONBfb4or/Wyln9Q": [
                "Texture/Loading/frame-18",
                "cc.SpriteFrame",
                1
            ],
            "8cY0mURtdIxIRg0MEnOIK2": [
                "Texture/Loading/frame-18.png",
                "cc.Texture2D"
            ],
            "38det8xJhJ2ZfUs4B15/m5": [
                "Texture/Loading/frame-19",
                "cc.SpriteFrame",
                1
            ],
            "92irLcL9hLOrZGsDffq33L": [
                "Texture/Loading/frame-19.png",
                "cc.Texture2D"
            ],
            "0b8rts3slPwKdpF2dGJl+L": [
                "Texture/Loading/frame-2",
                "cc.SpriteFrame",
                1
            ],
            "1eUFGsWoJDGIuoxp9kKr/h": [
                "Texture/Loading/frame-2.png",
                "cc.Texture2D"
            ],
            c8OZ5xgSZKzqn88BXz1u4r: [
                "Texture/Loading/frame-20",
                "cc.SpriteFrame",
                1
            ],
            "088VxFS0xBsKgYrHaKFmjR": [
                "Texture/Loading/frame-20.png",
                "cc.Texture2D"
            ],
            "30ejq0mR9OuaEd6lAaAHj5": [
                "Texture/Loading/frame-21",
                "cc.SpriteFrame",
                1
            ],
            "d3FLtS/4RLloaWRn8QjZWu": [
                "Texture/Loading/frame-21.png",
                "cc.Texture2D"
            ],
            "f8/bfpk0lFK5bE3OT2/6HA": [
                "Texture/Loading/frame-22",
                "cc.SpriteFrame",
                1
            ],
            "8bZOzddudDx6uCDgl6MU/8": [
                "Texture/Loading/frame-22.png",
                "cc.Texture2D"
            ],
            "cdCpGSfvdD9KXxh1/xnhj3": [
                "Texture/Loading/frame-23",
                "cc.SpriteFrame",
                1
            ],
            f0gBiPJv9MqIzLC4FogROp: [
                "Texture/Loading/frame-23.png",
                "cc.Texture2D"
            ],
            "b3su6z3WVHla5+rCnFLIBF": [
                "Texture/Loading/frame-24",
                "cc.SpriteFrame",
                1
            ],
            "43vB2vET9BKYpKOL+y0iSC": [
                "Texture/Loading/frame-24.png",
                "cc.Texture2D"
            ],
            d11bjveO1A1bpcDIkIfMzG: [
                "Texture/Loading/frame-25",
                "cc.SpriteFrame",
                1
            ],
            "09CmdrqXlGY5s5K9B/pwDM": [
                "Texture/Loading/frame-25.png",
                "cc.Texture2D"
            ],
            "e3okltdVFCxZqgUPZ/Lt5T": [
                "Texture/Loading/frame-26",
                "cc.SpriteFrame",
                1
            ],
            "0aXzALL5hHgp28nA30NCyN": [
                "Texture/Loading/frame-26.png",
                "cc.Texture2D"
            ],
            da7hLlmR9FFr0NTlXOp5af: [
                "Texture/Loading/frame-27",
                "cc.SpriteFrame",
                1
            ],
            "16gFl4oFJNVZzD1sYdkgj0": [
                "Texture/Loading/frame-27.png",
                "cc.Texture2D"
            ],
            aejgqWTTlBK7K4cRaMMDzr: [
                "Texture/Loading/frame-28",
                "cc.SpriteFrame",
                1
            ],
            "74b3sOpA9OoZWmCQ0IpCiK": [
                "Texture/Loading/frame-28.png",
                "cc.Texture2D"
            ],
            "eexkE8GPpHzrow+rrVFrZe": [
                "Texture/Loading/frame-29",
                "cc.SpriteFrame",
                1
            ],
            "70a1Vi2qZK54Y+Aio1W29s": [
                "Texture/Loading/frame-29.png",
                "cc.Texture2D"
            ],
            "28C551CNVOqqJvkRc6+a68": [
                "Texture/Loading/frame-3",
                "cc.SpriteFrame",
                1
            ],
            "66u0fVHPNGA77FK8Fta+JS": [
                "Texture/Loading/frame-3.png",
                "cc.Texture2D"
            ],
            b1x8EtquNJepPwa2kWXIrh: [
                "Texture/Loading/frame-4",
                "cc.SpriteFrame",
                1
            ],
            "940lJS5k5P+IHQi50lBhuk": [
                "Texture/Loading/frame-4.png",
                "cc.Texture2D"
            ],
            "15QG41dptBA50aA9KYdpes": [
                "Texture/Loading/frame-5",
                "cc.SpriteFrame",
                1
            ],
            "57a2o6SyRDNZ9dG9wrBFOf": [
                "Texture/Loading/frame-5.png",
                "cc.Texture2D"
            ],
            "46YNosGNJMyLx+ZzKzn0jg": [
                "Texture/Loading/frame-6",
                "cc.SpriteFrame",
                1
            ],
            e7m4YWMXpFfKWpRKccSFyh: [
                "Texture/Loading/frame-6.png",
                "cc.Texture2D"
            ],
            a99PoYgFlLm6chXFIcjj2r: [
                "Texture/Loading/frame-7",
                "cc.SpriteFrame",
                1
            ],
            "28XwvVthRAB5ltJ/vNq6AK": [
                "Texture/Loading/frame-7.png",
                "cc.Texture2D"
            ],
            f6Ev6OHOtCuKIlxlreEEFr: [
                "Texture/Loading/frame-8",
                "cc.SpriteFrame",
                1
            ],
            "dcL0NEGkpIjof1LU6oiuw/": [
                "Texture/Loading/frame-8.png",
                "cc.Texture2D"
            ],
            "91R49vIwRJ0bP5GrmERQ4l": [
                "Texture/Loading/frame-9",
                "cc.SpriteFrame",
                1
            ],
            "b9NE8SWNZH/JY/Z6Vxw6nS": [
                "Texture/Loading/frame-9.png",
                "cc.Texture2D"
            ],
            "31b9FHeLRA0rvOikYRsik1": [
                "Texture/Seat",
                "cc.SpriteFrame",
                1
            ],
            "2adrEgQM5JkpNtFq2SF+aa": [
                "Texture/Seat.png",
                "cc.Texture2D"
            ],
            d6yhHNFFBBhIqZ6VcSggf0: [
                "Texture/Table",
                "cc.SpriteFrame",
                1
            ],
            "563SnIfX1JvrKpvqhjz9uG": [
                "Texture/Table.png",
                "cc.Texture2D"
            ],
            "54HB5zHypDr5q2Aq+hdT2n": [
                "Texture/background",
                "cc.SpriteFrame",
                1
            ],
            "8cdKRazVRGWI9If85z9z5s": [
                "Texture/background.jpg",
                "cc.Texture2D"
            ],
            "f17h+wHhFFGK0tITbNbLaK": [
                "Texture/cards.plist",
                "cc.SpriteAtlas"
            ],
            c4AmISWylDT5qcVmu6Eq16: [
                "Texture/cards.png",
                "cc.Texture2D"
            ],
            "53VcHu721KnqERnWPC/ta0": [
                "Texture/default",
                "cc.SpriteFrame",
                1
            ],
            "b51CaFkGFMj4B/V33Lcf6n": [
                "Texture/default.jpg",
                "cc.Texture2D"
            ],
            fciEbPgnVJgKtQmSrMLOIn: [
                "Texture/pixel",
                "cc.SpriteFrame",
                1
            ],
            "52aqQOagZAr7gOyJyvhyiP": [
                "Texture/pixel.jpg",
                "cc.Texture2D"
            ],
            "18i7YwpzRIvK4iogrfWZnZ": [
                "Texture/splash",
                "cc.SpriteFrame",
                1
            ],
            "05Y2FQZu9KPaOdgxfrt5t5": [
                "Texture/splash.jpg",
                "cc.Texture2D"
            ]
        }
    },
    jsList: [
        "assets/Script/GameSparks/gamesparks-rt.js",
        "assets/Script/GameSparks/gamesparks.js",
        "assets/Script/GameSparks/hmac-sha256.js"
    ],
    launchScene: "db://assets/Scene/Boot.fire",
    scenes: [
        {
            url: "db://assets/Scene/Boot.fire",
            uuid: "497hb1B01KUrUduV82rA/D"
        },
        {
            url: "db://assets/Scene/Game.fire",
            uuid: "9f/YigPU9NtqnN17WvlVOu"
        }
    ],
    packedAssets: {
        "01daf4fc3": [
            "01gRzUseZBXqeyIQAGebRt",
            "08IyvD7/tDbp5uWmTRmqKR",
            "17m3TLrFhLc5RdbZMsK6NH",
            "17ssb4Ff9Eipuzb7Of/UxO",
            "18sD5Jn4ZBmrYx8ZZ/B7YX",
            "19vnm7h1pB0o6YW7RQNODd",
            "1a+DD+jeNPhJY6Z/AjU4cE",
            "1dHoXQ4qZD1LPR8DMtOz+Z",
            "1fFy3eaddNjK8h/MRgo5iY",
            "2277wYT/ZPcL5AJeMNsIvl",
            "26RCS5bfZM87hMqv6P0THD",
            "26ZxVDh3RACKlZAZrFdieI",
            "290i1dQ5lF85OciaJ3qytB",
            "31UE9Ga5lMC4tbWu9oOkCv",
            "3fXAqXsXhCIpFWrC2oPFzh",
            "43fCBc4ypAJ7TKWE57/3aW",
            "4a59ibRv9Gj4ZQoGZJGnMa",
            "4d4095VAdM/bOjVSQtgoHI",
            "5eLIE8T05MOYP793/W8/Za",
            "5ez6HCYoVDqK7PV8EISMYg",
            "5fEHYW5w5Gu5+9zraoB15p",
            "60blh8rJlP0Lk7GKrMUoo+",
            "6cM6qd8LdDYbcbhIjP8+Bh",
            "70ESkHOsZGlpSwzhXuP0V4",
            "779NcPFYBMnZvDFIHlOt9e",
            "78Zoz4z5FIo7C3kAH1KRl+",
            "7ablFXmd1Dp57FSeMF/dTN",
            "7cw7kdPJdAerUwVMWZlygU",
            "7fnA8HfRZHVJzKfurf3Bir",
            "84AFL3og9D9aK1xmeDXxdX",
            "87EcdqsgVNRLOIeT2HAA9b",
            "8dOoJZrhVBWp70lPzMD6fA",
            "91FnX3TSFBnaiWtow4/8To",
            "9cY9naHdxEFbT6eTLXwrVW",
            "9eRk7/GGJJ44t+dQR325mE",
            "a1aGbaY/FOy7OuY7Xv1xdE",
            "ad9Q+zLr5H7YGfJhbZYdBS",
            "aeJ/jqLBxCJZdt5kpfx2K5",
            "afy6xc2I9OsJaXTKdZFT1O",
            "b50tbQtJBByai8BG2NeVfO",
            "b56zPLLnNFqaO1SUtLiEiI",
            "b63DHsP69KE6B3apPmio0N",
            "baylxQOMtMh4S85nHrqEHt",
            "bbO17rVvBAoZ3CcLVkBDHq",
            "bbkC4YnkNIe7by12fuu5Ws",
            "cc7mRFAvBE/6vTiWGKmwGF",
            "d283fr9hpOoJeL+/BsdZTE",
            "d5CO6A5wFC/LxbfVTdc6He",
            "dbC9pl/f9G/K8pgx6kV6al",
            "dcRCilvwxAErqURRmt/6Kg",
            "dfVwACf61AZIEyyvSxSHv9",
            "e6s4w8jitBAqL1D38dlDZF",
            "ecaimiw9lGpZOX5iXk3UyX",
            "f17h+wHhFFGK0tITbNbLaK",
            "fcPA0wuPhPn5V6Vp8aTfje"
        ],
        "05227162c": [
            "0b8rts3slPwKdpF2dGJl+L",
            "10NqWh1ZVNNb1kEAe6VyRk",
            "15QG41dptBA50aA9KYdpes",
            "28C551CNVOqqJvkRc6+a68",
            "30ejq0mR9OuaEd6lAaAHj5",
            "31b9FHeLRA0rvOikYRsik1",
            "38det8xJhJ2ZfUs4B15/m5",
            "44dmFC6MZOeZQTnbVfGBsk",
            "46YNosGNJMyLx+ZzKzn0jg",
            "53VcHu721KnqERnWPC/ta0",
            "54HB5zHypDr5q2Aq+hdT2n",
            "73Whe0ryFBKrsyv0LKUx8f",
            "87yGeX+k1G2oJj7UyDzSYs",
            "91R49vIwRJ0bP5GrmERQ4l",
            "9f/YigPU9NtqnN17WvlVOu",
            "a2MjXRFdtLlYQ5ouAFv/+R",
            "a99PoYgFlLm6chXFIcjj2r",
            "abEu7yE+xFJYkvW/gdDVKa",
            "adg0WekRFO1ofUR5zFx0E6",
            "aejgqWTTlBK7K4cRaMMDzr",
            "b1x8EtquNJepPwa2kWXIrh",
            "b3su6z3WVHla5+rCnFLIBF",
            "b5KwyrhupJsKFmjZbVPzjU",
            "b5Xf8bsV5M7ITS/1xUK7SQ",
            "b8+11Hz99HKJK6gB0B/EHN",
            "c8OZ5xgSZKzqn88BXz1u4r",
            "cabXkubvJEl44NxY7HL0XK",
            "ccEsQ/A8JGR7bRnbxyZKcH",
            "cdCpGSfvdD9KXxh1/xnhj3",
            "d11bjveO1A1bpcDIkIfMzG",
            "d6yhHNFFBBhIqZ6VcSggf0",
            "da7hLlmR9FFr0NTlXOp5af",
            "e3okltdVFCxZqgUPZ/Lt5T",
            "e8T6Y0sUNIG7LXnzqyNkl7",
            "eaMw1eYONBfb4or/Wyln9Q",
            "eexkE8GPpHzrow+rrVFrZe",
            "f6Ev6OHOtCuKIlxlreEEFr",
            "f8/bfpk0lFK5bE3OT2/6HA",
            "fciEbPgnVJgKtQmSrMLOIn"
        ],
        "09d0ee43f": [
            "02delMVqdBD70a/HSD99FK",
            "03w5fB6Y1J3Zsm1hLLvjHx",
            "05Y2FQZu9KPaOdgxfrt5t5",
            "088VxFS0xBsKgYrHaKFmjR",
            "09CmdrqXlGY5s5K9B/pwDM",
            "0aXzALL5hHgp28nA30NCyN",
            "10tmRch2lO7Jpv40kgi5mX",
            "14vb/Yh5RI0Y+G/hZ6t/M7",
            "16FGsWsIZJWIUmufHNRQSD",
            "16gFl4oFJNVZzD1sYdkgj0",
            "1eUFGsWoJDGIuoxp9kKr/h",
            "28XwvVthRAB5ltJ/vNq6AK",
            "2adrEgQM5JkpNtFq2SF+aa",
            "3b4u53J3lC95Jj8VI0hLBb",
            "43vB2vET9BKYpKOL+y0iSC",
            "52aqQOagZAr7gOyJyvhyiP",
            "563SnIfX1JvrKpvqhjz9uG",
            "57a2o6SyRDNZ9dG9wrBFOf",
            "65oLWRJP1LppfrquGq0zJI",
            "66u0fVHPNGA77FK8Fta+JS",
            "70a1Vi2qZK54Y+Aio1W29s",
            "74b3sOpA9OoZWmCQ0IpCiK",
            "8bZOzddudDx6uCDgl6MU/8",
            "8cY0mURtdIxIRg0MEnOIK2",
            "8cdKRazVRGWI9If85z9z5s",
            "92irLcL9hLOrZGsDffq33L",
            "940lJS5k5P+IHQi50lBhuk",
            "99FwsL0hBG8bITfZ4/IwmK",
            "99tm7mqFxASo1a7ZOnLqQZ",
            "b51CaFkGFMj4B/V33Lcf6n",
            "b9NE8SWNZH/JY/Z6Vxw6nS",
            "c4AmISWylDT5qcVmu6Eq16",
            "c8yvF1B1FKM7bZbhIpWkGo",
            "cf73jxyN9Jt47QTJU6ziYh",
            "d3FLtS/4RLloaWRn8QjZWu",
            "dcL0NEGkpIjof1LU6oiuw/",
            "e7m4YWMXpFfKWpRKccSFyh",
            "e92OZtgL1IqoKZbJwcyJtJ",
            "f0gBiPJv9MqIzLC4FogROp",
            "fcB7VZ86pG8YWamkUFmRaR"
        ],
        "0b09fbcae": [
            "18i7YwpzRIvK4iogrfWZnZ",
            "497hb1B01KUrUduV82rA/D",
            "675ovJ2tVK2aLYfgPUWOMv",
            "8855/VlrRKd6H0MSRnFxAU"
        ]
    },
    md5AssetsMap: {},
    orientation: "landscape",
    debug: true,
    subpackages: {}
};
